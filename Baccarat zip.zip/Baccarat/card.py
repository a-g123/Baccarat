from tkinter import PhotoImage

#Creating the class for the card image - setting optional properies in the class function
class Card:
    def __init__(self, image=None, value=1, suit=None, name=None):
        self.__imgCard = PhotoImage(file='images/back_blue.png')
        self.__width = self.__imgCard.width()
        self.__height = self.__imgCard.height()
        self.__value = 1
        self.__suit = None
        self.__name = None 
    
    def getImage(self):
        """returns the image of the card
        
        Returns:
            card: the image
        """
        return self.__imgCard
    
    def setImage(self, img):
        self.__imgCard = img
        """set the image of the card
        
        Args:
            img (Photoimage): the image that should be outputted
        """

    def setValue(self, val):
        self.__value = val
        """set the value of the card
        
        Args:
            val (int): the value the card should be declared as
        """

    def getValue(self):
        """returns the value of the card
        
        Returns:
            value: the card value that has been set
        """
        return self.__value
    
    def setSuit(self, suit):
        """set the suit of the card
        
        Args:
            suit (str): the suit the card should be declared as
        """
        self.__suit = suit
    
    def getSuit(self):
        """returns the suit of the card
        
        Returns:
            suit: the card suit that has been set
        """
        return self.__suit
    
    def setName(self, name):
        """set the name of the card
        
        Args:
            name (str): the name the card should be declared as
        """
        self.__name = name
    
    def getName(self):
        """returns the name of the card
        
        Returns:
            name: the card name that has been set
        """
        return self.__name
    
    def getWidth(self):
        """returns the width of the card
        
        Returns:
            width: the card width that has been set
        """
        return self.__width
    
    def getHeight(self):
        """returns the height of the card
        
        Returns:
            width: the card height that has been set
        """
        return self.__height