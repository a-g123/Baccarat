from card import Card
from tkinter import PhotoImage
import random

#Creating the class for the deck of cards - setting optional properies in the class function
class DeckofCards:
    def __init__(self, isshuffled=False):
        self.__deck = []
        index = 0
        suits = ('Clubs', 'Diamonds', 'Spades', 'Hearts')
        self.__cardsdealt = -1
        self.__cardsremaining = 52
        #Photos are getting initilized by getting added to the list, given a value, suit and name
        for x in range(2, 15):
            for z in range(4):
                self.__deck.append(Card())
                self.__deck[index].setImage(PhotoImage(file=f'images/{x}{suits[z][0]}.png'))
                self.__deck[index].setValue(x)
                self.__deck[index].setSuit(suits[z])

                if x == 11:
                    self.__deck[index].setName(f'JACK of {suits[z].upper()}')
                elif x == 12:
                    self.__deck[index].setName(f'QUEEN of {suits[z].upper()}')
                elif x == 13:
                    self.__deck[index].setName(f'KING of {suits[z].upper()}')
                elif x == 11:
                    self.__deck[index].setName(f'ACE of {suits[z].upper()}')
                else:
                    self.__deck[index].setName(f'{x} of {suits[z].upper()}')
                index += 1
        #If the user writes 'True' in the constructor, they want the cards to be shuffled and then a call will be made to the shuffle function
        if isshuffled == True:
            self.Shuffle()
    
    def getCardsRemaining(self):
        """returns the number of cards remaining
        
        Returns:
            card: the remaining cards in the deck
        """
        return self.__cardsremaining

    def dealCard(self):
        """returns the card that has been dealt

        Returns:
            card: the first card in the deck
        """
        self.__cardsdealt += 1
        self.__cardsremaining -= 1
        return self.__deck[self.__cardsdealt]
    
    def Shuffle(self):
        """the function shuffles the deck for the programer
        """
        random.shuffle(self.__deck)
        self.__cardsdealt = -1
        self.__cardsremaining = len(self.__deck)